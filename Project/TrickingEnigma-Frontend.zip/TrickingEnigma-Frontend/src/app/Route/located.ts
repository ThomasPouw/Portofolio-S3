export enum Located {
  Side,
  Top,
  Both
}
