export enum PieceDirection {
  "North",
  "East",
  "South",
  "West"
}
