export interface TrackRecord{
  position?: number;
  courseName?: string;
  userName: string;
  time: number | string;
  turns: number;
  nationality?: string;
}
