package tccavy.tricklingenigma.levelservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LevelServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
