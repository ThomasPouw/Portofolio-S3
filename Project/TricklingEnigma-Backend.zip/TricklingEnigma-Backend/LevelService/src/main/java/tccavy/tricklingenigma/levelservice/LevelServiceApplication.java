package tccavy.tricklingenigma.levelservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

@EnableWebMvc
@SpringBootApplication
public class LevelServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(LevelServiceApplication.class, args);
    }

}//http://localhost:8040/swagger-ui/index.html#/ Hello!
