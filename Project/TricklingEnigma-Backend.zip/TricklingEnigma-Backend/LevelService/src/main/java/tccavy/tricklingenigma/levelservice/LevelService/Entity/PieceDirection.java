package tccavy.tricklingenigma.levelservice.LevelService.Entity;

public enum PieceDirection {
    North,
    East,
    South,
    West
}
