package tccavy.tricklingenigma.recordservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RecordServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
